# Setup

## Jenkins jobs on master

Create folder `NetBoot` and two regular Pipeline jobs. Each uses Pipeline script
from SCM, Git, your repository URL/credential and branch specifier `*/master`.

| Job | Script Path |
| --- | --- |
| `NetBoot/netboot-fleet` | `Jenkinsfile` |
| `NetBoot/netboot-board` | `child-pipeline/Jenkinsfile` |

A file in Git does not create a Jenkins job. Run the child once after creating it
so Declarative parameters are registered. Initially use a known board and version.
Run again after changing parameter definitions before using the parent.

For Multibranch Pipeline use the appropriate branch job, for example
`/NetBoot/netboot-board/master`, in `config/boards.yaml`.

Required plugins: Pipeline (including Declarative and Basic Steps), Git,
Pipeline: Build Step, Pipeline Utility Steps (`readYaml`), SSH Agent,
Credentials Binding, Timestamper, and Lockable Resources (`lock`).

Credentials:
- `boot-server-ssh`: SSH private key for `jenkins-deploy` on the server.
- `board-ssh`: SSH private key for `netboot-deploy` on boards.
- `artifactory-token`: Secret text read access token.
- Git credentials if the repository is private.

Agents need Bash, Python 3, OpenSSH tools, curl and sha256sum. Configure trusted
known_hosts for server and boards on every eligible agent. At least two eligible
executors are needed for two simultaneous child builds. Avoid a shared customWorkspace.
Use dedicated build agents rather than adding executors to the Jenkins controller.

All builds select master, but a moving master can result in different commits among
children. For reproducibility add an explicit commit-SHA parameter and checkout that
revision in each child; this starter does not pin revisions.

## Boot server

Example server: 192.168.50.10. All `/srv/netboot` paths are deliberately fixed in this
starter. If changing the root, update Jenkins, deployment path validation, server
scripts, template, exports and TFTP configuration together.

The server needs Bash, util-linux (`flock`, `losetup`, `mount`, `mountpoint`), coreutils,
udevadm, NFS server and TFTP server. WIC extraction requires root and loop devices;
use a trusted server VM or host that permits mounts. Partition device nodes must be
created by `losetup --partscan`; scripts stop if they are absent.

Create the deployment account and SSH access, copy this repository to the server,
then run as root from its checkout:

```bash
bash server/install-tools.sh
```

Configure TFTP to serve `/srv/netboot`. Kernel paths are relative to that TFTP root:
`releases/product-a/release/2.5.0-42/Image` and the corresponding `board.dtb`.

Review `server/exports.example`, change the VLAN subnet, install the reviewed file
as `/etc/exports.d/netboot.exports`, then run `exportfs -ra`. Confirm the exported
parent allows mounting descendants with your NFS server configuration. Enable NFSv3
TCP and the required rpcbind/mountd ports between boards and server. Restrict access
to the isolated board network.

Grant the deployment account passwordless sudo for the installed publication and
rootfs tools and the specific server-side install command used by the deployment.
The server scripts operate on trusted images as root; use only controlled Artifactory
artifacts. Restrict sudo and access to the deployment account accordingly. Do not
copy a broad `NOPASSWD: ALL` rule.

Never modify the cached release tree. A release has a `.complete` marker containing
its WIC SHA256. Extracting is atomic and protected by a server flock. Existing caches
from other scripts without that marker are not reused; inspect/migrate them offline.
If an existing version directory lacks its marker, publication stops for inspection.

## Artifactory layout

For product-a, release, version 2.5.0-42, upload:

```text
 yocto-images/product-a/2.5.0-42/product-a-release-2.5.0-42.wic
 yocto-images/product-a/2.5.0-42/product-a-release-2.5.0-42.wic.sha256
```

Checksum file: a single SHA256 digest, optionally followed by a filename.
The pipeline validates it locally and the server validates uploaded bytes again.

## Board and Yocto prerequisites

The running board must already accept SSH at BOARD_IP so this pipeline can install
uEnv.txt. This does not recover a powered-off or unbootable board; use serial console,
power control or an alternate known-good boot medium for that case.

BOARD_BOOT_MOUNT must be the mounted local boot partition, both before deployment
and after NFS boot. Ensure the Yocto image's fstab mounts that partition at this path.
A directory named /boot alone is insufficient: the deployment checks mountpoint.

The Yocto rootfs must contain the board deploy user, authorized key, SSH service,
grep, awk, mountpoint, systemctl, systemd-run and the necessary sudo rules. Grant
only the required install and reboot scheduling commands. The user must exist in
both the current OS and the new rootfs. Validate `systemd-run --on-active=3s` on your
image; this example uses systemd and is not compatible with SysV-only images.

The kernel must have NIC driver, IP autoconfiguration and NFS root support built in
(or supplied by a suitable initramfs; the example uses no initramfs). Configure Yocto
network services so they do not replace the static kernel-assigned IP unexpectedly.
Check fstab for local root remounts that conflict with NFS root.

Review template variables for your board:
- Console `ttyS2,115200n8` is an AM625 example.
- `eth0` is a kernel boot-time interface example; verify your NIC naming.
- `loadaddr` and `fdtaddr` must already be valid, nonoverlapping U-Boot addresses.
- `booti` assumes an ARM64 Linux Image.
- The actual boot command must import uEnv.txt and run `uenvcmd`.
- RAM layout, DTB, kernel compatibility and TFTP network access must be confirmed.

Installing uEnv.txt alone does not alter a U-Boot boot flow that never imports it.
Keep serial console available while commissioning the first board.

## Running

Edit defaults once for shared settings. Board entries override any child parameter.
For install-only, set both REBOOT_BOARD and HEALTH_CHECK to false. A normal run uses
both true. To use prepublished releases only set PUBLISH_IF_MISSING to false.

The child records uEnv.txt and deployment.txt as Jenkins artifacts. Failed branches
do not stop other boards; the parent fails if any child fails. Inspect each child
build log for the failing SSH or server command. Timeouts include lock and queue wait.

The reboot check waits up to 36 attempts with five-second sleeps plus SSH time.
It verifies that boot ID changed, assignment markers match, and `/` is mounted as NFS.
If it fails use serial console; this starter does not perform automatic rollback.

## Validation status

The delivered bundle was checked for Python compilation, Bash syntax, configuration
shape, parameter rejection and uEnv rendering. Real Jenkins scheduling, sudo, WIC
mount/extraction, U-Boot, TFTP/NFS and reboot require your lab and were not exercised.
