#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$EUID" == 0 ]] || { echo 'Run as root on the boot server' >&2; exit 1; }
cd "$(dirname "$0")"
install -d -m 0755 /usr/local/libexec/wic-netboot /srv/netboot/releases /srv/netboot/boards /srv/netboot/locks
install -m 0755 common.sh publish-wic-release.sh prepare-board-rootfs.sh /usr/local/libexec/wic-netboot/
# Requires this account to already exist.
install -d -o jenkins-deploy -g jenkins-deploy -m 0750 /srv/netboot/staging
