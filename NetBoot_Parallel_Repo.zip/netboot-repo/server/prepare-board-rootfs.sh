#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
require_root
[[ $# == 4 ]] || { echo 'Usage: prepare PRODUCT TYPE VERSION BOARD_ID' >&2; exit 1; }
product=$1; type=$2; version=$3; board=$4
for name in "$product" "$type" "$version" "$board"; do safe_name "$name" || exit 1; done
[[ "$type" == release || "$type" == debug ]] || exit 1
release="$NETBOOT_ROOT/releases/$product/$type/$version"
root="$NETBOOT_ROOT/boards/$board/roots/$product/$type/$version"
[[ -f "$release/.complete" && -d "$release/rootfs/etc" ]] || { echo 'Release missing' >&2; exit 1; }
mkdir -p "$NETBOOT_ROOT/locks" "$(dirname "$root")"
exec 9>"$NETBOOT_ROOT/locks/root-$board.lock"
flock -x 9
if [[ -d "$root" ]]; then
    # Preserve an existing writable root. Never remove a live NFS root.
    for pair in "BOARD_ID=$board" "PRODUCT=$product" "IMAGE_TYPE=$type" "VERSION=$version"; do
        grep -qx "$pair" "$root/etc/netboot-assignment" || exit 1
    done
    exit 0
fi
work=$(mktemp -d "$(dirname "$root")/.prepare.XXXXXXXXXX")
trap 'rm -rf -- "$work"' EXIT
cp -a --reflink=auto "$release/rootfs/." "$work/"
# Remove image symlinks for files written here so writes cannot escape this tree.
rm -f "$work/etc/netboot-assignment" "$work/etc/hostname" "$work/etc/machine-id"
printf 'BOARD_ID=%s\nPRODUCT=%s\nIMAGE_TYPE=%s\nVERSION=%s\n' "$board" "$product" "$type" "$version" > "$work/etc/netboot-assignment"
printf '%s\n' "$board" > "$work/etc/hostname"
: > "$work/etc/machine-id"
# Do not configure network/fstab generically: those are Yocto image-specific.
mv -T "$work" "$root"
