#!/usr/bin/env bash
set -Eeuo pipefail
NETBOOT_ROOT=/srv/netboot
safe_name() {
    [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ && "$1" != . && "$1" != .. ]]
}
safe_relative() {
    [[ "$1" =~ ^[A-Za-z0-9._/-]+$ && "$1" != /* && "$1" != . && "$1" != */ ]]
    [[ "/$1/" != */../* ]]
}
require_root() { [[ "$EUID" == 0 ]] || { echo 'Run as root' >&2; exit 1; }; }
