#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
require_root
[[ $# == 9 ]] || { echo 'Usage: publish WIC PRODUCT TYPE VERSION BOOT_PART ROOT_PART KERNEL DTB SHA256' >&2; exit 1; }
wic=$1; product=$2; type=$3; version=$4; boot_part=$5; root_part=$6; kernel=$7; dtb=$8; expected=$9
for name in "$product" "$type" "$version"; do safe_name "$name" || exit 1; done
[[ "$type" == release || "$type" == debug ]] || exit 1
[[ "$boot_part" =~ ^[1-9][0-9]*$ && "$root_part" =~ ^[1-9][0-9]*$ ]] || exit 1
safe_relative "$kernel" && safe_relative "$dtb" || exit 1
[[ "$expected" =~ ^[a-f0-9]{64}$ ]] || exit 1
[[ "$wic" == /srv/netboot/staging/upload.*/*.wic && -f "$wic" ]] || exit 1
# Resolve paths to prevent traversal or symlinks escaping the upload tree.
wic=$(realpath -e "$wic")
[[ "$wic" == /srv/netboot/staging/upload.*/*.wic ]] || exit 1
release="$NETBOOT_ROOT/releases/$product/$type/$version"
mkdir -p "$NETBOOT_ROOT/locks" "$(dirname "$release")"
exec 9>"$NETBOOT_ROOT/locks/release-$product-$type-$version.lock"
flock -x 9
if [[ -f "$release/.complete" ]]; then
    [[ "$(cat "$release/.complete")" == "$expected" ]] || { echo 'Immutable version already has a different checksum' >&2; exit 1; }
    echo "Release already published: $release"
    exit 0
fi
[[ ! -e "$release" ]] || { echo 'Incomplete release exists; inspect before retrying' >&2; exit 1; }
[[ "$(sha256sum "$wic" | awk '{print $1}')" == "$expected" ]] || exit 1
work=$(mktemp -d "$(dirname "$release")/.extract.XXXXXXXXXX")
loop=''
cleanup() {
    mountpoint -q "$work/boot" && umount "$work/boot" || true
    mountpoint -q "$work/root" && umount "$work/root" || true
    [[ -z "$loop" ]] || losetup -d "$loop" || true
    rm -rf -- "$work"
}
trap cleanup EXIT
mkdir "$work/boot" "$work/root" "$work/payload"
loop=$(losetup --find --show --partscan --read-only "$wic")
udevadm settle
[[ -b "${loop}p${boot_part}" && -b "${loop}p${root_part}" ]] || { echo 'WIC partition nodes absent' >&2; exit 1; }
mount -o ro "${loop}p${boot_part}" "$work/boot"
mount -o ro "${loop}p${root_part}" "$work/root"
# Reject symlinks resolving outside the mounted boot partition.
for path in "$kernel" "$dtb"; do
    resolved=$(realpath -e "$work/boot/$path")
    [[ "$resolved" == "$work/boot/"* && -s "$resolved" ]] || exit 1
done
install -m 0644 "$work/boot/$kernel" "$work/payload/Image"
install -m 0644 "$work/boot/$dtb" "$work/payload/board.dtb"
mkdir "$work/payload/rootfs"
cp -a "$work/root/." "$work/payload/rootfs/"
[[ -d "$work/payload/rootfs/etc" ]] || exit 1
printf '%s\n' "$expected" > "$work/payload/.complete"
umount "$work/boot"
umount "$work/root"
losetup -d "$loop"
loop=''
# Same-filesystem rename exposes only a complete release to other builds.
mv -T "$work/payload" "$release"
echo "Published $release"
