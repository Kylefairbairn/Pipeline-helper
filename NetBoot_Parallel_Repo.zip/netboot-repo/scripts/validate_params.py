#!/usr/bin/env python3
"""Validate all values that are interpolated into remote shell commands."""
import ipaddress
import os
import re
from pathlib import PurePosixPath

def fail(message):
    raise SystemExit(message)

def validate():
    for key in ('PRODUCT', 'VERSION', 'BOARD_ID'):
        value = os.environ.get(key, '')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', value) or value in ('.', '..'):
            fail(f'Invalid {key}')
    for key in ('BOARD_IP', 'SERVER_IP', 'GATEWAY_IP'):
        try:
            ipaddress.IPv4Address(os.environ[key])
        except (KeyError, ValueError):
            fail(f'Invalid {key}')
    try:
        ipaddress.IPv4Network('0.0.0.0/' + os.environ['NETMASK'])
    except (KeyError, ValueError):
        fail('Invalid NETMASK')
    for key in ('BOOT_PARTITION', 'ROOT_PARTITION'):
        if not re.fullmatch(r'[1-9][0-9]*', os.environ.get(key, '')):
            fail(f'Invalid {key}')
    for key in ('KERNEL_PATH', 'DTB_PATH', 'BOARD_BOOT_MOUNT'):
        value = os.environ.get(key, '')
        absolute = key == 'BOARD_BOOT_MOUNT'
        if (not re.fullmatch(r'[A-Za-z0-9._/-]+', value) or
            value.startswith('/') != absolute or '..' in value.split('/') or
            value in ('.', '/') or not PurePosixPath(value).name):
            fail(f'Invalid {key}')
    if os.environ.get('SCRIPT_IMPL') not in ('python', 'bash'):
        fail('Invalid SCRIPT_IMPL')
    if os.environ.get('IMAGE_TYPE') not in ('release', 'debug'):
        fail('Invalid IMAGE_TYPE')
    for key in ('PUBLISH_IF_MISSING', 'REBOOT_BOARD', 'HEALTH_CHECK'):
        if os.environ.get(key) not in ('true', 'false'):
            fail(f'Invalid {key}')
    if os.environ['HEALTH_CHECK'] == 'true' and os.environ['REBOOT_BOARD'] != 'true':
        fail('HEALTH_CHECK requires REBOOT_BOARD; disable health check for install-only runs')

if __name__ == '__main__':
    validate()
    print('Parameters validated')
