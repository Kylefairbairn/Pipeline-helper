#!/usr/bin/env python3
"""Compatibility entry point. Both selections intentionally share the Bash backend."""
import subprocess
from pathlib import Path
subprocess.run(['bash', str(Path(__file__).with_name('deploy-board.sh'))], check=True)
