#!/usr/bin/env bash
set -Eeuo pipefail
python3 scripts/validate_params.py
ssh_opts=(-o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=5 -o ServerAliveInterval=10 -o ServerAliveCountMax=3)
release="$NETBOOT_ROOT/releases/$PRODUCT/$IMAGE_TYPE/$VERSION"
staging=''
cleanup() {
    if [[ -n "$staging" ]]; then
        ssh "${ssh_opts[@]}" "$BOOT_SERVER" "rm -rf -- '$staging'" || true
    fi
}
trap cleanup EXIT
wic="$PRODUCT-$IMAGE_TYPE-$VERSION.wic"
relative="$PRODUCT/$VERSION/$wic"
# Cache hit is explicit: distinguish missing cache (3) from SSH/authentication failure.
if ssh "${ssh_opts[@]}" "$BOOT_SERVER" "if test -f '$release/.complete'; then exit 0; else exit 3; fi"; then
    echo "Using cached release $release"
else
    status=$?
    [[ "$status" == 3 ]] || exit "$status"
    [[ "$PUBLISH_IF_MISSING" == true ]] || { echo 'Release missing and publication disabled' >&2; exit 1; }
    mkdir -p download
    # Do not expose the token to shell tracing.
    set +x
    curl --fail --location --retry 3 -H "Authorization: Bearer $ARTIFACTORY_TOKEN" \
        -o "download/$wic" "$ARTIFACTORY_BASE/$ARTIFACTORY_REPO/$relative"
    curl --fail --location --retry 3 -H "Authorization: Bearer $ARTIFACTORY_TOKEN" \
        -o "download/$wic.sha256" "$ARTIFACTORY_BASE/$ARTIFACTORY_REPO/$relative.sha256"
    expected=$(awk 'NR==1 {print $1}' "download/$wic.sha256")
    [[ "$expected" =~ ^[a-fA-F0-9]{64}$ ]] || { echo 'Invalid checksum file' >&2; exit 1; }
    actual=$(sha256sum "download/$wic" | awk '{print $1}')
    [[ "${expected,,}" == "$actual" ]] || { echo 'Checksum mismatch' >&2; exit 1; }
    staging=$(ssh "${ssh_opts[@]}" "$BOOT_SERVER" "mktemp -d '$NETBOOT_ROOT/staging/upload.XXXXXXXXXX'")
    [[ "$staging" =~ ^/srv/netboot/staging/upload\.[A-Za-z0-9]+$ ]] || exit 1
    scp "${ssh_opts[@]}" "download/$wic" "$BOOT_SERVER:$staging/$wic"
    ssh "${ssh_opts[@]}" "$BOOT_SERVER" \
        "sudo /usr/local/libexec/wic-netboot/publish-wic-release.sh '$staging/$wic' '$PRODUCT' '$IMAGE_TYPE' '$VERSION' '$BOOT_PARTITION' '$ROOT_PARTITION' '$KERNEL_PATH' '$DTB_PATH' '$actual'"
fi
ssh "${ssh_opts[@]}" "$BOOT_SERVER" \
    "sudo /usr/local/libexec/wic-netboot/prepare-board-rootfs.sh '$PRODUCT' '$IMAGE_TYPE' '$VERSION' '$BOARD_ID'"
python3 scripts/render_uenv.py templates/uEnv.txt.template uEnv.txt
printf 'BOARD_ID=%s\nPRODUCT=%s\nIMAGE_TYPE=%s\nVERSION=%s\n' "$BOARD_ID" "$PRODUCT" "$IMAGE_TYPE" "$VERSION" > deployment.txt
record=$(ssh "${ssh_opts[@]}" "$BOOT_SERVER" "mktemp '$NETBOOT_ROOT/staging/uenv.XXXXXXXXXX'")
[[ "$record" =~ ^/srv/netboot/staging/uenv\.[A-Za-z0-9]+$ ]] || exit 1
scp "${ssh_opts[@]}" uEnv.txt "$BOOT_SERVER:$record"
ssh "${ssh_opts[@]}" "$BOOT_SERVER" \
    "sudo install -m 0644 '$record' '$NETBOOT_ROOT/boards/$BOARD_ID/uEnv.txt' && rm -f '$record'"
board="$BOARD_USER@$BOARD_IP"
# Record boot ID so a check cannot accidentally pass on the pre-reboot boot.
old_boot=$(ssh "${ssh_opts[@]}" "$board" 'cat /proc/sys/kernel/random/boot_id')
remote_tmp=$(ssh "${ssh_opts[@]}" "$board" 'mktemp /tmp/netboot-uenv.XXXXXXXXXX')
[[ "$remote_tmp" =~ ^/tmp/netboot-uenv\.[A-Za-z0-9]+$ ]] || exit 1
scp "${ssh_opts[@]}" uEnv.txt "$board:$remote_tmp"
ssh "${ssh_opts[@]}" "$board" \
    "mountpoint -q '$BOARD_BOOT_MOUNT' && sudo install -m 0644 '$remote_tmp' '$BOARD_BOOT_MOUNT/uEnv.txt' && rm -f '$remote_tmp' && sync"
if [[ "$REBOOT_BOARD" == true ]]; then
    # Schedule reboot so SSH can normally report successful submission before shutdown.
    ssh "${ssh_opts[@]}" "$board" 'sudo systemd-run --on-active=3s /bin/systemctl reboot'
fi
if [[ "$REBOOT_BOARD" == true && "$HEALTH_CHECK" == true ]]; then
    success=false
    for attempt in $(seq 1 36); do
        if ssh "${ssh_opts[@]}" "$board" \
            "test \"\$(cat /proc/sys/kernel/random/boot_id)\" != '$old_boot' && \
            grep -qx 'BOARD_ID=$BOARD_ID' /etc/netboot-assignment && \
            grep -qx 'PRODUCT=$PRODUCT' /etc/netboot-assignment && \
            grep -qx 'IMAGE_TYPE=$IMAGE_TYPE' /etc/netboot-assignment && \
            grep -qx 'VERSION=$VERSION' /etc/netboot-assignment && \
            awk '\$2 == \"/\" && (\$3 == \"nfs\" || \$3 == \"nfs4\") {found=1} END {exit !found}' /proc/mounts"; then
            success=true
            break
        fi
        sleep 5
    done
    [[ "$success" == true ]] || { echo 'Board health check failed' >&2; exit 1; }
fi
