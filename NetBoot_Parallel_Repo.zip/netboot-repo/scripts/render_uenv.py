#!/usr/bin/env python3
"""Replace deployment variables; preserve U-Boot runtime variables."""
import os
import re
import sys
from pathlib import Path
keys = ('BOARD_ID', 'PRODUCT', 'IMAGE_TYPE', 'VERSION', 'BOARD_IP', 'SERVER_IP', 'GATEWAY_IP', 'NETMASK')
source, destination = sys.argv[1:]
text = Path(source).read_text()
for key in keys:
    text = text.replace('${' + key + '}', os.environ[key])
if re.search(r'\$\{(?:' + '|'.join(keys) + r')\}', text):
    raise SystemExit('Unresolved deployment variable')
Path(destination).write_text(text)
